﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace ChServer
{
    public partial class Form1 : Form
    {
        TcpListener server = null; // 서버
        TcpClient clientSocket = null; // 소켓
        // 각 클라이언트 마다 리스트에 추가
        public Dictionary<TcpClient, string> clientList = new Dictionary<TcpClient, string>();
        NetworkStream stream = default(NetworkStream);
        public Form1()
        {
            InitializeComponent();
        }
        private void InitSocket()
        {
            int port = int.Parse(txt_Port.Text);
            server = new TcpListener(port);
            clientSocket = default(TcpClient);
            server.Start();
            Message("--------Server Start--------");

            while(true)
            {
                try
                {
                    clientSocket = server.AcceptTcpClient();//클라이언트가 소켓에 접속하는 것을 허용

                    NetworkStream stream = clientSocket.GetStream();
                    byte[] buffer = new byte[1024];
                    int bytes = stream.Read(buffer, 0, buffer.Length);
                    string nickname = Encoding.Unicode.GetString(buffer, 0, bytes);

                    nickname = nickname.Substring(0, nickname.IndexOf("$")); // client 사용자 명
                    clientList.Add(clientSocket, nickname); // 클라이언트 리스트에 추가
                    Msg_To_Client(nickname + " 님이 입장하셨습니다.", ""); // 모든 client에게 메세지 전송
                    Message(nickname + "님이 입장하셨습니다.");
                    handle h_client = new handle(); // 클라이언트 추가
                    h_client.OnReceived += new handle.MessageDisplayHandler(OnReceived);
                    h_client.OnDisconnected += new handle.DisconnectedHandler(h_client_OnDisconnected);
                    h_client.startClient(clientSocket, clientList);
                }
                catch(SocketException e) { break; }
                catch(Exception e) { break; }
            }
            clientSocket.Close();
            server.Stop();
        }
        void h_client_OnDisconnected(TcpClient c) // 클라이언트 접속 해제 되었을 때 리스트에서 삭제
        {
            if (clientList.ContainsKey(c))
                clientList.Remove(c);
        }
        private void OnReceived(string message, string nickname) 
        {
            if (message.Equals("quit"))
            {
                string msg =  nickname + "님이 나가셨습니다";
                Message(msg);
                Msg_To_Client("quit", nickname);
            }

            else
            {
                string msg = nickname + " : " + message;
                Message(msg); 
                Msg_To_Client(message, nickname);
            }
        }
        public void Msg_To_Client(string msg, string nickname)
        {
            foreach (var pair in clientList)
            {
                TcpClient client = pair.Key as TcpClient;
                NetworkStream stream = client.GetStream();
                byte[] buffer = null;

                    if (msg.Equals("quit"))
                        buffer = Encoding.Unicode.GetBytes(nickname + " 님이 대화방을 나갔습니다.");
                    else
                        buffer = Encoding.Unicode.GetBytes(nickname + " : " + msg);

                stream.Write(buffer, 0, buffer.Length); // 버퍼 쓰기
                stream.Flush();
            }
        }
        private void Message(string text) // Server 화면에 출력
        {
                txt_all.BeginInvoke(new MethodInvoker(delegate
                {
                    txt_all.AppendText(text + "\r\n");
                }));
        }

        private void btn_send_Click(object sender, EventArgs e)
        {
            Msg_To_Client(txt_send.Text, "System");
            Message("System : " + txt_send.Text);
            txt_send.Text = "";
        }
        private void txt_send_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) // 엔터키 눌렀을 때
                btn_send_Click(this, e);
        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            Thread t = new Thread(InitSocket);
            t.IsBackground = true;
            t.Start();
        }
    }
}
