﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Net.Sockets;

namespace ChClient
{
    public partial class Form1 : Form
    {
        TcpClient clientSocket = new TcpClient(); // 소켓
        NetworkStream stream = default(NetworkStream);
        string message = string.Empty;
        public Form1()
        {
            InitializeComponent();
        }

        private void txt_all_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void btn_send_Click(object sender, EventArgs e)
        {
            txt_send.Focus();
            byte[] buffer = Encoding.Unicode.GetBytes(txt_send.Text + "$");
            stream.Write(buffer, 0, buffer.Length);
            stream.Flush();
            txt_send.Text = "";
        }
        private void Receive() 
        { 
            while (true)
            {
                stream = clientSocket.GetStream();
                int BUFFERSIZE = clientSocket.ReceiveBufferSize;
                byte[] buffer = new byte[BUFFERSIZE];
                int bytes = stream.Read(buffer, 0, buffer.Length);
                string message = Encoding.Unicode.GetString(buffer, 0, bytes);
                Message(message);
            }
        }
        private void Message(string text) // Server에 출력
        {
                txt_all.BeginInvoke(new MethodInvoker(delegate
                {
                    txt_all.AppendText(text + "\r\n");
                }));
        }
        private void txt_send_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) // 엔터키 눌렀을 때
                btn_send_Click(this, e);
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e) // 폼 닫을 때 실행
        {
            byte[] buffer = Encoding.Unicode.GetBytes("quit" + "$"); //종료신호 전송
            stream.Write(buffer, 0, buffer.Length);
            stream.Flush();
            Application.ExitThread();
            Environment.Exit(0);
        }

        private void btn_connect_Click(object sender, EventArgs e)
        {
            try
            {
                int port = int.Parse(txt_Port.Text); //포트번호 int형 변환
                clientSocket.Connect(txt_IP.Text, port); // 접속 IP 및 포트
                stream = clientSocket.GetStream();
            }
            catch (Exception e2)
            {
                MessageBox.Show("서버가 실행중이지 않습니다..");
                Application.Exit();
            }

            message = "채팅 서버에 연결 되었습니다.";
            Message(message);
            byte[] buffer = Encoding.Unicode.GetBytes(txt_NickName.Text + "$");
            stream.Write(buffer, 0, buffer.Length);
            stream.Flush();
            Thread t_handler = new Thread(Receive);
            //t_handler.IsBackground = true;
            t_handler.Start();
        }
    }
}
